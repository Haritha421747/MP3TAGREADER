#include <stdio.h>
#include "types.h"
#include "view.h"
#include "edit.h"

int main(int argc, char* argv[])
{
    TagInfo mp3tagInfo;
    TagData mp3tagData;

    //If the argument count print the format in which the arguments shall be passed.
    if (argc < 2)		
    {
        printf ("ERROR: Incorrect format of Command Line Arguments.\n");
        printf ("INFO: Use \"./mp3_tag_reader --help\" for Help menu.\n");
    }
    else
    {
        //To check which Operation type and store into ret
        OperationType ret = check_operation (argv);
        //if the return type is view 		
        if (ret == p_view)				
        {
            printf ("--------------------------\n");
            printf ("MP3 Tag Reader and Editor\n");
            printf ("--------------------------\n");
            //To validate all the arguments passed in Command Line in view
            Status ret1 = read_and_validate_mp3_file (argv, &mp3tagInfo);
            //If validation is successful, proceed with the Viewing process.		
            if (ret1 == p_success)
            {
                //To execute the Viewing process of the MP3 Tag.
                Status ret2 = view_tag (argv, &mp3tagInfo);
                //If the Viewing process is successfully executed, print a confirmation message.						
                if (ret2 == p_success)		
                {
                    printf ("INFO: VIEW PART DONE SUCCESSFUL.\n");
                    printf ("--------------------------\n");
                }
            }
        }
        //If the return value from the function is to perform Editing the mp3
        else if (ret == p_edit)			
        {
            printf ("MP3 Tag Reader and Editor:\n");
            printf ("--------------------------\n");
            //To validate all the arguments passed in Command Line.
            Status ret1 = read_and_validate_mp3_file_args (argv, &mp3tagData);
            //If validation is successful, proceed with the Editing process.	
            if (ret1 == p_success)			
            {
                //To execute the Editing process of the MP3 Tag.
                Status ret2 = edit_tag (argv, &mp3tagData);	
                //If the Editing process is successfully executed, print a confirmation message.
                if (ret2 == p_success)		
                {
                    printf ("INFO: EDIT PART DONE SUCCESSFULLY.\n");
                    printf ("--------------------------\n");
                    //Call the view_tag function to display the Updated content.
                }
            }
        }
        //if the return value to show the help menu,display the usage of mp3 taf reader&editor
        else if (ret == p_help)		
        {
            printf ("INFO: Help Menu for Tag Reader and Editor:\n");
            printf ("INFO: For Viewing the Tags -> ./mp3_tag_reader -v <file_name.mp3>\n");
            printf ("INFO: For Editing the Tags -> ./mp3_tag_reader -e <modifier> \"New_Value\" <file_name.mp3>\n");
            printf ("INFO: Modifier Functions:\n");
            printf ("-t\tModify Title Tag\n-A\tModify Artist Tag\n-a\tModify Album Tag\n-y\tModify Year Tag\n-G\tModify Content Type Tag\n-c\tModify Comments Tag\n");
        }
        //If perform View/Edit/Help, print an error message.
        else if (ret == p_unsupported)	
        {
            printf ("ERROR: Unsupported Operation.\n");
            printf ("INFO: Use \"./mp3_tag_reader --help\" for Help menu.\n");
        }
    }

    return 0;
}