/*NAME:G.Haritha
Date:17/11/24
Description:MP3 TAGREADER*/
//SAMPLEINPUT /SAMPLEOUTPUT FOR VIEW PART:
haritha@LAPTOP-NQOEOIIB:~/MP3_TAG_READER$ ./a.out 
ERROR: Incorrect format of Command Line Arguments.
INFO: Use "./mp3_tag_reader --help" for Help menu.
haritha@LAPTOP-NQOEOIIB:~/MP3_TAG_READER$ ./a.out -t
ERROR: Unsupported Operation.
INFO: Use "./mp3_tag_reader --help" for Help menu.
haritha@LAPTOP-NQOEOIIB:~/MP3_TAG_READER$ ./a.out -t k
ERROR: Unsupported Operation.
INFO: Use "./mp3_tag_reader --help" for Help menu.
haritha@LAPTOP-NQOEOIIB:~/MP3_TAG_READER$ ./a.out -v k
--------------------------
MP3 Tag Reader and Editor
--------------------------
ERROR: Unable to Open the k file.
INFO: For Viewing the Tags -> ./mp3_tag_reader -v <file_name.mp3>
haritha@LAPTOP-NQOEOIIB:~/MP3_TAG_READER$ ./a.out --help
INFO: Help Menu for Tag Reader and Editor:
INFO: For Viewing the Tags -> ./mp3_tag_reader -v <file_name.mp3>
INFO: For Editing the Tags -> ./mp3_tag_reader -e <modifier> "New_Value" <file_name.mp3>
INFO: Modifier Functions:
-t      Modify Title Tag
-A      Modify Artist Tag
-a      Modify Album Tag
-y      Modify Year Tag
-G      Modify Content Type Tag
-c      Modify Comments Tag
haritha@LAPTOP-NQOEOIIB:~/MP3_TAG_READER$ ./a.out -v 
--------------------------
MP3 Tag Reader and Editor
--------------------------
INFO: For Viewing the Tags -> ./mp3_tag_reader -v <file_name.mp3>
haritha@LAPTOP-NQOEOIIB:~/MP3_TAG_READER$ ./a.out -v sample.mp3 
--------------------------
MP3 Tag Reader and Editor
--------------------------
     Version ID: v2.3     
--------------------------
MP3 position = 10.
Title: Size = 6.
Title:    bunny.
MP3 position = 26.
Artist: Size = 33.
Artist:   Yo Yo Honey Singh - [SongsPk.CC].
MP3 position = 69.
Album: Size = 11.
Album:    honeysingh.
MP3 position = 90.
Year: Size = 5.
Year:     2024.
MP3 position = 105.
Content: Size = 10.
Content:  tollywood.
MP3 position = 125.
Comments: Size = 31.
Comments: eng.
--------------------------
INFO: VIEW PART DONE SUCCESSFUL.
--------------------------
haritha@LAPTOP-NQOEOIIB:~/MP3_TAG_READER$ hd sample.mp3 |head
00000000  49 44 33 03 00 00 00 10  13 19 54 49 54 32 00 00  |ID3.......TIT2..|
00000010  00 06 00 00 00 62 75 6e  6e 79 54 50 45 31 00 00  |.....bunnyTPE1..|
00000020  00 21 00 00 00 59 6f 20  59 6f 20 48 6f 6e 65 79  |.!...Yo Yo Honey|
00000030  20 53 69 6e 67 68 20 2d  20 5b 53 6f 6e 67 73 50  | Singh - [SongsP|
00000040  6b 2e 43 43 5d 54 41 4c  42 00 00 00 0b 00 00 00  |k.CC]TALB.......|
00000050  68 6f 6e 65 79 73 69 6e  67 68 54 59 45 52 00 00  |honeysinghTYER..|
00000060  00 05 00 00 00 32 30 32  34 54 43 4f 4e 00 00 00  |.....2024TCON...|
00000070  0a 00 00 00 74 6f 6c 6c  79 77 6f 6f 64 43 4f 4d  |....tollywoodCOM|
00000080  4d 00 00 00 1f 00 00 00  65 6e 67 00 44 6f 77 6e  |M.......eng.Down|
00000090  6c 6f 61 64 65 64 20 46  72 6f 6d 20 53 6f 6e 67  |loaded From Song|
//SAMPLEINPUT /SAMPLEOUTPUT FOR VIEW PART:
haritha@LAPTOP-NQOEOIIB:~/MP3_TAG_READER$ ./a.out
ERROR: Incorrect format of Command Line Arguments.
INFO: Use "./mp3_tag_reader --help" for Help menu.
haritha@LAPTOP-NQOEOIIB:~/MP3_TAG_READER$ ./a.out p
ERROR: Unsupported Operation.
INFO: Use "./mp3_tag_reader --help" for Help menu.
haritha@LAPTOP-NQOEOIIB:~/MP3_TAG_READER$ ./a.out --help
INFO: Help Menu for Tag Reader and Editor:
INFO: For Viewing the Tags -> ./mp3_tag_reader -v <file_name.mp3>
INFO: For Editing the Tags -> ./mp3_tag_reader -e <modifier> "New_Value" <file_name.mp3>
INFO: Modifier Functions:
-t      Modify Title Tag
-A      Modify Artist Tag
-a      Modify Album Tag
-y      Modify Year Tag
-G      Modify Content Type Tag
-c      Modify Comments Tag
haritha@LAPTOP-NQOEOIIB:~/MP3_TAG_READER$ ./a.out -e 
MP3 Tag Reader and Editor:
--------------------------
INFO: For Editing the Tags -> ./mp3_tag_reader -e <modifier> "New_Value" <file_name.mp3>
INFO: Modifier Functions:
-t      Modify Title Tag
-A      Modify Artist Tag
-a      Modify Album Tag
-y      Modify Year Tag
-M      Modify Content Type Tag
-c      Modify Comments Tag
haritha@LAPTOP-NQOEOIIB:~/MP3_TAG_READER$ ./a.out -e -a devisriprasad sample.mp3 
MP3 Tag Reader and Editor:
--------------------------
Frame ID to be changed: TALB.
Length of the Data in CLA = 14.
Updated Value of Frame ID is devisriprasad.
     Version ID: v2.3     
--------------------------
Size of the Frame ID content = 12.
Frame ID content = funny_funny.
MP3 position = 32.
Temp position = 32.
Size of the Frame ID content = 10.
Frame ID content = hollywood.
MP3 position = 52.
Temp position = 52.
Old Tag Data Size = 14.
New Tag Data Size = E000000.
New Data = devisriprasad.
MP3 position = 76.
Temp position = 76.
Size of the Frame ID content = 5.
Frame ID content = 2025.
MP3 position = 91.
Temp position = 91.
Size of the Frame ID content = 10.
Frame ID content = tollywood.
MP3 position = 111.
Temp position = 111.
Size of the Frame ID content = 31.
Frame ID content = eng.
MP3 position = 152.
Temp position = 152.
Copy Remaining Data:
MP3 position = 152.
Temp position = 152.
MP3 position = 8520000.
MP3 position = 152.
MP3 position = 8520000.
Temp position = 8520000.
Copy Data Back to Source:
Temp position = 0.
MP3 position = 0.
Temp position = 8520000.
Temp position = 0.
MP3 position = 8520000.
Temp position = 8520000.
INFO: EDIT PART DONE SUCCESSFULLY.
--------------------------
haritha@LAPTOP-NQOEOIIB:~/MP3_TAG_READER$ ./a.out -e -A pure_heroine sample.mp3 
MP3 Tag Reader and Editor:
--------------------------
Frame ID to be changed: TPE1.
Length of the Data in CLA = 13.
Updated Value of Frame ID is pure_heroine.
     Version ID: v2.3     
--------------------------
Size of the Frame ID content = 12.
Frame ID content = funny_funny.
MP3 position = 32.
Temp position = 32.
Old Tag Data Size = 10.
New Tag Data Size = D000000.
New Data = pure_heroine.
MP3 position = 52.
Temp position = 55.
Size of the Frame ID content = 14.
Frame ID content = devisriprasad.
MP3 position = 76.
Temp position = 79.
Size of the Frame ID content = 5.
Frame ID content = 2025.
MP3 position = 91.
Temp position = 94.
Size of the Frame ID content = 10.
Frame ID content = tollywood.
MP3 position = 111.
Temp position = 114.
Size of the Frame ID content = 31.
Frame ID content = eng.
MP3 position = 152.
Temp position = 155.
Copy Remaining Data:
MP3 position = 152.
Temp position = 155.
MP3 position = 8520000.
MP3 position = 152.
MP3 position = 8520000.
Temp position = 8520003.
Copy Data Back to Source:
Temp position = 0.
MP3 position = 0.
Temp position = 8520003.
Temp position = 0.
MP3 position = 8520003.
Temp position = 8520003.
INFO: EDIT PART DONE SUCCESSFULLY.
--------------------------
haritha@LAPTOP-NQOEOIIB:~/MP3_TAG_READER$ ./a.out -e -y 2025 sample.mp3 
MP3 Tag Reader and Editor:
--------------------------
Frame ID to be changed: TYER.
Length of the Data in CLA = 5.
Updated Value of Frame ID is 2025.
     Version ID: v2.3     
--------------------------
Size of the Frame ID content = 12.
Frame ID content = funny_funny.
MP3 position = 32.
Temp position = 32.
Size of the Frame ID content = 13.
Frame ID content = pure_heroine.
MP3 position = 55.
Temp position = 55.
Size of the Frame ID content = 14.
Frame ID content = devisriprasad.
MP3 position = 79.
Temp position = 79.
Old Tag Data Size = 5.
New Tag Data Size = 5000000.
New Data = 2025.
MP3 position = 94.
Temp position = 94.
Size of the Frame ID content = 10.
Frame ID content = tollywood.
MP3 position = 114.
Temp position = 114.
Size of the Frame ID content = 31.
Frame ID content = eng.
MP3 position = 155.
Temp position = 155.
Copy Remaining Data:
MP3 position = 155.
Temp position = 155.
MP3 position = 8520003.
MP3 position = 155.
MP3 position = 8520003.
Temp position = 8520003.
Copy Data Back to Source:
Temp position = 0.
MP3 position = 0.
Temp position = 8520003.
Temp position = 0.
MP3 position = 8520003.
Temp position = 8520003.
INFO: EDIT PART DONE SUCCESSFULLY.
--------------------------
haritha@LAPTOP-NQOEOIIB:~/MP3_TAG_READER$ ./a.out -e -M hollywood sample.mp3 
MP3 Tag Reader and Editor:
--------------------------
Frame ID to be changed: TCON.
Length of the Data in CLA = 10.
Updated Value of Frame ID is hollywood.
     Version ID: v2.3     
--------------------------
Size of the Frame ID content = 12.
Frame ID content = funny_funny.
MP3 position = 32.
Temp position = 32.
Size of the Frame ID content = 13.
Frame ID content = pure_heroine.
MP3 position = 55.
Temp position = 55.
Size of the Frame ID content = 14.
Frame ID content = devisriprasad.
MP3 position = 79.
Temp position = 79.
Size of the Frame ID content = 5.
Frame ID content = 2025.
MP3 position = 94.
Temp position = 94.
Old Tag Data Size = 10.
New Tag Data Size = A000000.
New Data = hollywood.
MP3 position = 114.
Temp position = 114.
Size of the Frame ID content = 31.
Frame ID content = eng.
MP3 position = 155.
Temp position = 155.
Copy Remaining Data:
MP3 position = 155.
Temp position = 155.
MP3 position = 8520003.
MP3 position = 155.
MP3 position = 8520003.
Temp position = 8520003.
Copy Data Back to Source:
Temp position = 0.
MP3 position = 0.
Temp position = 8520003.
Temp position = 0.
MP3 position = 8520003.
Temp position = 8520003.
INFO: EDIT PART DONE SUCCESSFULLY.
--------------------------
haritha@LAPTOP-NQOEOIIB:~/MP3_TAG_READER$ ./a.out -e -c poetic sample.mp3 
MP3 Tag Reader and Editor:
--------------------------
Frame ID to be changed: COMM.
Length of the Data in CLA = 7.
Updated Value of Frame ID is poetic.
     Version ID: v2.3     
--------------------------
Size of the Frame ID content = 12.
Frame ID content = funny_funny.
MP3 position = 32.
Temp position = 32.
Size of the Frame ID content = 13.
Frame ID content = pure_heroine.
MP3 position = 55.
Temp position = 55.
Size of the Frame ID content = 14.
Frame ID content = devisriprasad.
MP3 position = 79.
Temp position = 79.
Size of the Frame ID content = 5.
Frame ID content = 2025.
MP3 position = 94.
Temp position = 94.
Size of the Frame ID content = 10.
Frame ID content = hollywood.
MP3 position = 114.
Temp position = 114.
Old Tag Data Size = 31.
New Tag Data Size = 7000000.
New Data = poetic.
MP3 position = 155.
Temp position = 131.
Copy Remaining Data:
MP3 position = 155.
Temp position = 131.
MP3 position = 8520003.
MP3 position = 155.
MP3 position = 8520003.
Temp position = 8519979.
Copy Data Back to Source:
Temp position = 0.
MP3 position = 0.
Temp position = 8519979.
Temp position = 0.
MP3 position = 8519979.
Temp position = 8519979.
INFO: EDIT PART DONE SUCCESSFULLY.
--------------------------
haritha@LAPTOP-NQOEOIIB:~/MP3_TAG_READER$ hd temp.mp3 |head
00000000  49 44 33 03 00 00 00 10  13 19 54 49 54 32 00 00  |ID3.......TIT2..|
00000010  00 0c 00 00 00 66 75 6e  6e 79 5f 66 75 6e 6e 79  |.....funny_funny|
00000020  54 50 45 31 00 00 00 0d  00 00 00 70 75 72 65 5f  |TPE1.......pure_|
00000030  68 65 72 6f 69 6e 65 54  41 4c 42 00 00 00 0e 00  |heroineTALB.....|
00000040  00 00 64 65 76 69 73 72  69 70 72 61 73 61 64 54  |..devisriprasadT|
00000050  59 45 52 00 00 00 05 00  00 00 32 30 32 35 54 43  |YER.......2025TC|
00000060  4f 4e 00 00 00 0a 00 00  00 68 6f 6c 6c 79 77 6f  |ON.......hollywo|
00000070  6f 64 43 4f 4d 4d 00 00  00 07 00 00 00 70 6f 65  |odCOMM.......poe|
00000080  74 69 63 41 50 49 43 00  00 11 a9 00 00 00 69 6d  |ticAPIC.......im|
00000090  61 67 65 2f 6a 70 65 67  00 00 6c 6f 67 6f 2e 6a  |age/jpeg..logo.j|


haritha@LAPTOP-NQOEOIIB:~/MP3_TAG_READER$ hd sample.mp3 |head
00000000  49 44 33 03 00 00 00 10  13 19 54 49 54 32 00 00  |ID3.......TIT2..|
00000010  00 0c 00 00 00 66 75 6e  6e 79 5f 66 75 6e 6e 79  |.....funny_funny|
00000020  54 50 45 31 00 00 00 0d  00 00 00 70 75 72 65 5f  |TPE1.......pure_|
00000030  68 65 72 6f 69 6e 65 54  41 4c 42 00 00 00 0e 00  |heroineTALB.....|
00000040  00 00 64 65 76 69 73 72  69 70 72 61 73 61 64 54  |..devisriprasadT|
00000050  59 45 52 00 00 00 05 00  00 00 32 30 32 35 54 43  |YER.......2025TC|
00000060  4f 4e 00 00 00 0a 00 00  00 68 6f 6c 6c 79 77 6f  |ON.......hollywo|
00000070  6f 64 43 4f 4d 4d 00 00  00 07 00 00 00 70 6f 65  |odCOMM.......poe|
00000080  74 69 63 41 50 49 43 00  00 11 a9 00 00 00 69 6d  |ticAPIC.......im|
00000090  61 67 65 2f 6a 70 65 67  00 00 6c 6f 67 6f 2e 6a  |age/jpeg..logo.j|
